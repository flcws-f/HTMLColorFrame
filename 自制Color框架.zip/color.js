function playSound(path){
body.innerHTML=body.innerHTML+"<audio hidden src=path></audio>"
}